#' The application User-Interface
#' 
#' @param request Internal parameter for `{shiny}`. 
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_ui <- function(request) {
  tagList(
    # Leave this function for adding external resources
    golem_add_external_resources(),
    # Your application UI logic 
    fluidPage(
      h1("SADmain"),
      
      shiny::tableOutput('testtable'),
      
      shiny::selectInput('testinput', label = 'input', choices = NULL, selected = NULL),
      
      shiny::textOutput('testoutput')
      
            
      # ## App Title Bar
      # tags$div(
      #          id = 'titlebar',
      #          
      #          ## App Title
      #          h1(id = 'title', strong('SAD App')),
      #          
      #          ## IFWIS Logo
      #          tags$a(
      #                 id='IFWIS-logo',
      #                 href = 'http://ifwisshiny.idfg.state.id.us:3838/MC/WildlifeResearchWebsite/',
      #                 img(
      #                     src = 'www/WildlifeResearchPage_logo_small.png',
      #                     title = "View the adventures of the Wildlife Research Team",
      #                     height = '70px'
      #                    ) # img
      #                ), # a
      #         
      #         
      #         ## R Shiny Logo
      #         tags$a(
      #                id='shiny-logo',
      #                href='http://ifwisshiny.idfg.state.id.us:3838/EAR/IDFG_Wildlife_Shiny_Apps/',
      #                img(
      #                    src = 'www/r-shiny-logo.png',
      #                    title = 'Return to Wildlife Shiny Applications', 
      #                    height = '50px'
      #                   )
      #               ), # a
      #         
      #         ## IDFG Logo
      #         tags$a(
      #                id='IDFG-logo',
      #                href = 'https://idfg.idaho.gov/',
      #                img(
      #                    src = 'www/idfglogo.png',
      #                    title = 'Idaho Fish and Game',
      #                    height = '80px'
      #                   ) # img
      #               ) # a
      #             ) # div
          
      
    )
  )
}

#' Add external Resources to the Application
#' 
#' This function is internally used to add external 
#' resources inside the Shiny application. 
#' 
#' @import shiny
#' @importFrom golem add_resource_path activate_js favicon bundle_resources
#' @noRd
golem_add_external_resources <- function(){
  
  add_resource_path(
    'www', app_sys('app/www')
  )
 
  tags$head(
    favicon(),
    bundle_resources(
      path = app_sys('app/www'),
      app_title = 'SADmain'
    )
    # Add here other external resources
    # for example, you can add shinyalert::useShinyalert() 
  )
}

