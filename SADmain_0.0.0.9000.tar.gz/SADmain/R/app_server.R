#' The application server-side
#' 
#' @param input,output,session Internal parameters for {shiny}. 
#'     DO NOT REMOVE.
#' @import shiny
#' @noRd
app_server <- function( input, output, session ) {
  # Your application server logic 
  sql <- reactiveValues()
  
  observe({
           sql$con <- DBI::dbConnect(
                                    odbc::odbc(),
                                    driver   = '{ODBC Driver 17 for SQL Server}',
                                    # driver = "SQL Server",
                                    database = 'IFWIS_WildlifeReporting',
                                    uid      = 'ShinyUserInternal',
                                    pwd      = 'hurt seven sat pupil',
                                    server   = '164.165.105.241',
                                    port     = '1433'
                                   )
           
           sql$xx <- DBI::dbGetQuery(sql$con, 'SELECT * FROM AERIAL_PIC_Activity')
         })
  
  observe({
    output$testtable <- renderTable(sql$xx)
    updateSelectInput(inputId = 'testinput', choices = sql$xx$ActivityID)
  })
  output$testoutput <- renderText(input$testinput)
  
}
