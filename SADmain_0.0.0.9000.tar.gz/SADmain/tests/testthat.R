library(testthat)
library(SADmain)

test_check("SADmain")
